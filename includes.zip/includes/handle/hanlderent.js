const schedule = require("node-schedule");

schedule.scheduleJob("0 0 * * *", async function () {
    const allThreads = global.data.threadData;

    for (let [threadID, data] of allThreads) {
        if (data.rentDays && data.rentDays > 0) {
            data.rentDays--;

            await global.modules.get('Threads').setData(threadID, { data });
            global.data.threadData.set(parseInt(threadID), data);

            const botID = global.client.api.getCurrentUserID();

            // cập nhật lại biệt danh
            global.client.api.setNickname(
                `Pcoder | còn ${data.rentDays} ngày`,
                threadID,
                botID
            );

            // nếu hết ngày → bot out
            if (data.rentDays === 0) {
                global.client.api.sendMessage(
                    "⛔ Thời gian thuê bot đã hết. Bot sẽ rời nhóm.",
                    threadID
                );

                global.client.api.removeUserFromGroup(botID, threadID);
            }
        }
    }
});